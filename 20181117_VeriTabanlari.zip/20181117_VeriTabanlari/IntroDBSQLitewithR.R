# RLadies Introduction to Database & SQLite Demo with R
# install.packages("RSQLite")

# Step 1: Intro
  # SQLite Connect 
  require("RSQLite")
  SQLiteDriver <- dbDriver("SQLite")
  DBPath <- "C:/Users/mekmis/Desktop/RLadies/SQLite/db/RLadiesTestDB.db"
  ConRladies <- dbConnect(drv = SQLiteDriver,
                             DBPath,
                             synchronous = NULL)
  
  print(ConRladies)
  dbListTables(ConRladies)
  
  # SELECT
  # DBGetQuery
  TEST_TABLE <- dbGetQuery(ConRladies,
                          "SELECT * FROM TEST_TABLE")
  
  SendQuery <- dbSendQuery(ConRladies,
              "SELECT * FROM TEST_TABLE")
  
  fetch(SendQuery,1)
  
  print(TEST_TABLE)
  
  LogicDisconnect <-dbDisconnect(ConRladies)

# Step 2: Example mtcars
  help(mtcars)

  data(mtcars)

  SQLiteDriver <- dbDriver("SQLite")
  DBPath <- "C:/Users/mekmis/Desktop/RLadies/SQLite/db/mtcars.db"
 
  ConMtcars <- dbConnect(drv = SQLiteDriver,
                             DBPath,
                             synchronous = NULL)
  dbListTables(ConMtcars)
  
  # Data copy to "cars" table,
  dbWriteTable(conn = ConMtcars, 
               name = "cars",
               value =  mtcars,
               row.names =TRUE)
  
  # Select Table,
  dbGetQuery(conn = ConMtcars,
             statement = "SELECT * FROM cars")

  # Select Count(*)
  dbGetQuery(conn = ConMtcars,
             statement = "SELECT COUNT(*) FROM cars")
  
  # cars Colnames,
  dbListFields(conn = ConMtcars,
               name =  "cars")
  
  # Filter: mpg > 20
  dbGetQuery(conn = ConMtcars, 
             statement = "SELECT * FROM cars WHERE mpg > 20")

  # Filter: like 'Merc%'
  dbGetQuery(conn = ConMtcars, 
             statement = "SELECT * FROM cars WHERE row_names LIKE 'Merc%'")
  
  dbDisconnect(ConMtcars)

# Step 3: Simple Monte Carlo Simulation
  require("ggplot2")
  require("reshape2")
  require("RSQLite")

  SQLiteDriver <- dbDriver("SQLite")
  DBPath <- "C:/Users/mekmis/Desktop/RLadies/SQLite/db/RLadiesTestDB_2.db"
  ConRladies <- dbConnect(drv = SQLiteDriver,
                             DBPath,
                             synchronous = NULL)

  
  # 
  dbListTables(ConRladies)
  
  # Generate 100 values
  set.seed(1234)
  returns <- rnorm(n = 100, 
                  mean = 10, 
                  sd = 15)
  
  print(returns)
  # plot a histogram
  qplot(returns, 
        geom="histogram",
        binwidth = 1,
        main = "Histogram of returns") 
    
  set.seed(1234)
  sample(returns,size = 5)
  
  X <- matrix(ncol = 5,
             nrow = 1000)
  
  for(i in 1:5) {
    # for each i sample the return 1000 times
    for(j in 1:1000){
      RandomX <- rnorm(n = 100, mean = 10, sd = 15) 
      cat("i. value :",i,"j. value :",j,"\n")
      X[j,i] <- mean(RandomX)
    }
  }
  
  # Mean expected 
  apply(X = X,
        MARGIN = 2,
        FUN = mean)
  
  # Quantile of X[,]
  quantile(X[,1])
  
  # Histogram X[,]
  qplot(X[,1], geom="histogram",
        binwidth = 0.5,
        main = "Histogram of returns") 
    
  # Study Results Number: 1
  Results <- data.frame(STUDY_NUMBER = 1,X)
  
  # Write table
  dbListTables(ConRladies)
  dbWriteTable(conn = ConRladies,
               "SIMULATION_RESULTS",
               Results,
               append = FALSE # Table not exist
               )
  
  # Select Results
  SIMULATION_RESULTS <- dbSendQuery(conn = ConRladies,
                                    "SELECT * FROM SIMULATION_RESULTS")
  
  # fetch 50 Rows
  fetch(SIMULATION_RESULTS,n = 50)
  
  
  ## Results Study Number 2,3,..,10
  StudyNumbers <- 2:10
  for(k in StudyNumbers){
      for(i in 1:5) {
        # for each i sample the return 1000 times
        for(j in 1:1000){
          RandomX <- rnorm(n = 100, mean = 10, sd = 15) 
          X[j,i] = mean(RandomX)
        }
      }
    Results <- data.frame(STUDY_NUMBER = k,X)
    dbWriteTable(conn = ConRladies,
                 "SIMULATION_RESULTS",
                 Results,
                 append = TRUE # Table already exist
                 )
  }
  
  # Control Studies (DISTINCT STUDY)
  StudyList <- dbGetQuery(conn = ConRladies,
                          "SELECT DISTINCT STUDY_NUMBER  FROM SIMULATION_RESULTS;")
  
  print(StudyList)
  
  # Control Studies (COUNT(*), GROUP BY, ORDER BY  )
  StudyListWithCount <- dbGetQuery(conn = ConRladies,
                                    "SELECT STUDY_NUMBER,COUNT(*) 
                                        FROM SIMULATION_RESULTS
                                          GROUP BY STUDY_NUMBER
                                          ORDER BY STUDY_NUMBER ASC;")
  
  print(StudyListWithCount)
  
  # Analyze Attributes: X1, X2, X3, X4, X5
  # AVG() : Group By Averages 
  # AS : Alias, Name
  AnalyzeAttributes <- dbGetQuery(conn = ConRladies,
                                         "SELECT STUDY_NUMBER,
                                                 AVG(X1) AS MEAN_X1,
                                                 AVG(X2) AS MEAN_X2,
                                                 AVG(X3) AS MEAN_X3,
                                                 AVG(X4) AS MEAN_X4,
                                                 AVG(X5) AS MEAN_X5
                                         FROM SIMULATION_RESULTS
                                         GROUP BY STUDY_NUMBER
                                         ORDER BY STUDY_NUMBER ASC;")
  
  View(AnalyzeAttributes)
  
  AnalyzeAttributesMelt <- melt(AnalyzeAttributes, 
                                id.var = "STUDY_NUMBER")
  
  View(AnalyzeAttributesMelt)
  ggplot(data = AnalyzeAttributesMelt, 
         aes(x=variable, y=value)) + 
    geom_boxplot(aes(fill=STUDY_NUMBER))
  
  dbListTables(ConRladies)
  