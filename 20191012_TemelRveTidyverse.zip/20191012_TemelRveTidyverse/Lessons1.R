

#######  GIRIS #######

## Deger Atama
a<-10
print(a)

b=9
print(b)


##Toplama, Cikarma, Carpma, Bolme Islemleri
ab1=a+b
ab1

ab2=a-b
ab2

ab3=a*b
ab3

ab4=a/b
ab4

## Kare ve karekok alma
a^3
sqrt(b)
c<-a^3+sqrt(b)
c

# Text atama
myfirstword="Hello R Studio"
print(myfirstword)
 

result=c(19,1,9,1.11)   #birden fazla değer atanırken c() kullanılmaktadır
result

result=c("R Ladies'e Hoşgeldiniz", "Yine Bekleriz :)")
result

result=c(ab1, ab2, ab3, ab4)
result





## Veri Yapisi
# typeof(c)  #objenin tipi verir
# typeof(result)
# typeof(firstword)

#veri tipini verir
class(c)  
class(result)
class(myfirstword)

#veri yapisini ozetler
str(c)   
str(result)
str(myfirstword)

## Help 

?class
?str


## TRUE / FALSE 
fls=FALSE
fls

tr=TRUE
tr

##FALSE
tr==fls


#TRUE
bir=1
one=1

bir==one

a
b

a>b  #FALSE
a<b  #TRUE

logic=a>b  # a=10, b=9 iken bu komut TRUE verir
logic

###### VEKTORLER ve MATRISLER  ######

v=c(1,2,3,4,5,6,7,8,9)   #tek boyutlu 
m=matrix(vector)
m2=matrix(vector, nrow=3)  #2 boyutlu

###### VEKTORLER  ######
#Tek boyutlu bir sayi dizisidir
x=1
x
x=1:12
x

y=c(3,6,9,12,15)
y

#Vektor icinde veri secme
x[1]   #1. elemani secer
x[2]   #2. elemani secer
x[12]  #12. elemani secer
x[c(3,9)] #3. ve 9. elemani secer


x[1:6]  #1. elemandan 6. elemana kadar secer
x[9:12] #9. elemandan 12. elemana kadar secer

x[-1]   #1. elemani haric tutarak secer
x[-6]   #6. elemani haric tutarak secer
x[-c(1:6)]

#Vektor icine yeni eleman ekleme
length(x)
x[13]=13
x

length(x)
x[length(x)+1]
x[length(x)+1]=14
x



#Fonksiyon icinde kullanma
x
fx=2*x #x bir vektor oldugu icin tum elemanlarini 2 ile carpar
fx

x
fx=x^2+3*x+1
fx

x=1:7
y=0:6

x
y

fy=x*y  #x ve y vektorudeki degerleri birbirleri ile carpar
fy

fn=x-y
fn

#Vektorlerde Islemler
set.seed(2043)  #random sayi atanirkan ayni sayilarin gelmesi icin cekirdek set eder.
veri=rnorm (1000, 10, 2)   # 100 adet, ortalaması 10, standart sapması 2 olan normal dagılan sayi üretir
mean(veri)
median(veri)
sd(veri)
hist(veri)
summary(veri)
sum(veri)


###### MATRISLER  ######
#1'den fazla boyutlu sayilar dizisidir

x=seq(0,20,5)    #0'dan baslayarak 20'e kadar 5'er artırarak vektor olustur
y=seq(5,1,-1)    #5'den baslayarak 1'e kadar 1'er azaltarak vektor olustur

?seq   #seq:sequence

print(x)
print(y)

#Matrislerin uzunlarini bulalim
length(x)
length(y)

#Matrislerin uzunluklari birbirine esit mi kontrol edelim
length(x)==length(y)    #TRUE verirse vektorlerin uzunlari birbirine esittir

m=matrix(c(x,y), nrow=5, ncol = 2)
m

?matrix()

##martisin ozelliklerine bakalim
class(m)
str(m)

#Matris icinde veri secme
m[1,1]   #1. sutunun 1. satırındaki elemani secer
m[2,1]   #1. sutunun 2. satırındaki elemani secer
m[3,1]   #1. sutunun 3. satırındaki elemani secer

m[1,2]   #2. sutunun 1. satırındaki elemani secer
m[2,2]   #3. sutunun 2. satırındaki elemani secer
m[3,2]   #4. sutunun 3. satırındaki elemani secer

m[1,]   #1. satirin tum sütunu secer
m[2,]   #2. satirin tum sütunu secer
m[3,]   #3. satirin tum sütunu secer

m[,1]   #1. sutunun tum satırları secer
m[,2]   #2. sutunun tum satırları secer


## Matirslerde Islemler
a=matrix(1:12, nrow=3)
b=matrix(1:12, nrow=4)
print(a)
print(b)
c=a%*%b  # matrisleri carpak icin %*% operatoru kullanılır
print(c)

##Tranpose
d=t(c)
print(d)

## Veri setinin matris veya vektor olup olmadigi sorgulanabilir.
is.vector(c)
is.matrix(c)


# Vektörler
# Listeler
# Matrisler
# Diziler
# Faktörler
# Veri Çerçeveleri

###### LISTELER ve FAKTORLER   ######

###### LISTELER  ######
# farklı veri tiplerini ve farklı boyutlarda tek bir listeye alabilir
a=c(1,2,3)
b=c("Red", "Green")

a
b
c

l=list(a,b,c)
print(l)

#Olusturdugumuz listenin veri tipi ve ozellikleri

class(l)
str(l)


###### FAKTORLER  ######
gender=c(rep("male",20), rep("female",20))   # 20 kere male ve female yazdırır
gender

?rep  #rep:replicate

#Olusturdugumuz listenin veri tipi ve ozellikleri
typeof(gender)
class(gender)
str(gender)

## String / Karakter veriyi FAKTOR'e cevirme
sex=factor(gender)

typeof(sex)
class(sex)
str(sex)










