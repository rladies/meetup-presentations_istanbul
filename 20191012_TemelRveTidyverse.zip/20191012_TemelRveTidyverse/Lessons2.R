
rm(list=ls())
install.packages("data.table")
library(data.table)


## data.table ile data.frame. i anlat
## data.frame : Verilerin R'da belirli cervevelerde tablo halinde saklanmasi halidir. Esit uzunluktaki vektorlerin listesidir.
## data.table: data.frame'in gelistirilmis halidir. Verieri tablo formatlarinda tutar.

## data.frame ve data table farklari : 
## 1. Buyuk verilerde islem yapmak data table daha hizlidir.
## 2. data.table ile anlasilmasi ve kullanilmasi daha kolay kod yazilir.
## 3. veri okumada data.table daha hizlidir.

datasets::mtcars
mtcars_df=data.frame(mtcars)
class(mtcars_df)

dt=data.table(mtcars)

class(df)
class(dt)
str(df)
str(dt)


datasets::Titanic
tf=data.frame(Titanic)
Titanic_dt=data.table(Titanic)

class(tf)
class(Titanic_dt)
str(tf)
str(Titanic_dt)

summary(Titanic_dt)
Titanic_dt$Class=as.factor(Titanic_dt$Class)
Titanic_dt$Sex=as.factor(Titanic_dt$Sex)
Titanic_dt$Age=as.factor(Titanic_dt$Age)
Titanic_dt$Survived=as.factor(Titanic_dt$Survived)


##Kolonlarin isimleri
names(Titanic_dt)

##Kolon secme
Titanic_dt[,"Class"]
Titanic_dt[,Class]
Titanic_dt$Class

Titanic_dt[,c("Class", "Sex")]

##Satir secme
Titanic_dt[1:5,]
Titanic_dt[1:5, c("Class", "Sex")]

#ilk 10 satiri cekme
head(Titanic_dt)
head(Titanic_dt, 10)

#Filtreleme (Kosullu Veri Secme)
unique(Titanic_dt$Class)
Titanic_dt[Class=="1st"]
Titanic_dt[Class=="2nd"]

Titanic_dt[Sex=="Male"]


Titanic_dt[N>0]
Titanic_dt[N==0]
Titanic_dt[N>=50]

#kadinlardan olenlerin sayisina bakalim
Titanic_dt[Sex=="Female" & Survived == "No"]
Titanic_dt[Sex=="Female" & Age != "Child" & Survived == "No"]

Titanic_dt[Class=="1st" | Class=="2nd"]
Titanic_dt[(Class=="1st" | Class=="2nd") & Survived == "Yes"]

# in komutu
Titanic_dt[Sex %in% "Male"]

# not in 
Titanic_dt[!(Sex %in% "Male")]

#between komutu
Titanic_dt[N %between% c(50, 100) ]

#benzer komutu
Titanic_dt[Age %like% "%dul%"]
Titanic_dt[Age %like% "Adul%"]
Titanic_dt[Age %like% "%ld"]

#veri duzenleme (order)
Titanic_dt[order(Class)]

Titanic_dt[order(Class, Sex)]
Titanic_dt[order(-Class, Sex)]

Titanic_dt[order(Class, Sex, Age, Survived)]

#siralamayi datatable'a isleme
setorder(Titanic_dt, Class, Sex, Age, Survived)

# Titanic_dt[order(Titanic_dt[,Class],Titanic_dt[,Sex])]
# # Titanic_dt[with(Titanic_dt, order(Class, Sex))]
# Titanic_dt[with(Titanic_dt, order(Class, Sex))]
# Titanic_dt[with(Titanic_dt, order(Class, Sex, Age, Survived))]
# attach(Titanic_dt) 
# detach(Titanic_dt)


##Tekrarsiz Veri Secme
unique(Titanic_dt$Class)
Titanic_dt[,unique(Class)]


##kolon ekleme/cikarma
Titanic_dt[, Gemi:="Titanic"]
Titanic_dt[, Gemi:=NULL]

##kolon adi degistirme
setnames(Titanic_dt, "N", "Number")
Titanic_dt

#veri aggrete etme (mean, sum,max, min)
is.na(Titanic_dt)

Nop=sum(Titanic_dt$Number)

Titanic_dt[, Nop:=sum(Number, na.rm=TRUE)]
Titanic_dt[, NopofClass:=sum(Number, na.rm=TRUE), by="Class"]
Titanic_dt[, NopofSex:=sum(Number, na.rm=TRUE), by="Sex"]
Titanic_dt[, NopofAge:=sum(Number, na.rm=TRUE), by="Age"]
Titanic_dt[, NopofSurvived:=sum(Number, na.rm=TRUE), by="Survived"]

#Değişkenlerin toplamlari
Class=Titanic_dt[, .(N=sum(Number)), by="Class"]
Sex=Titanic_dt[, .(N=sum(Number)), by="Sex"]
Age=Titanic_dt[, .(N=sum(Number)), by="Age"]
Survived=Titanic_dt[, .(N=sum(Number)), by="Survived"]

#Değişkenlerin oranlari
Class=Class[, Ratio:= N/sum(N)]

Class=Class[, Ratio:= round(N/sum(N),2)]
Sex=Sex[, Ratio:=round(N/sum(N),2)]
Age=Age[, Ratio:=round(N/sum(N),2)]
Survived=Survived[, Ratio:=round(N/sum(N),2)]


## dplyr paketi
# Data islemede kodlamada yalınlık ve kolaylık saglayan, SQL diline benzeyen bir paket. 

install.packages("tidyverse")   #R içerisinde kullanacağımız özel komutları iceren paketler grubu
library(dplyr)

??dplyr

glimpse(Titanic_dt)
str(Titanic_dt) 


# %>% pipe operator : zincir operator , kısa yol ctrl + shift + m
#Bu operator dplyr komutlarını arka arkaya değisken adını tekrar yazmamıza gerek kalmayacak sekilde sıralamamızı 
#ve dolayısıyla daha okunabilir bir kod yazmamızı sağlıyor. 
#Kısaca aynı değişken üzerinde yapılacak islem sırasını düzenliyor.


#Kolon Secme
Titanic_dt %>% select (Class, Sex, Age, Survived, Number)

#Satir Secme
slice(Titanic_dt, 1:15)
slice(Titanic_dt, 10:15)

Titanic_dt %>% select (Class, Sex, Age, Survived, Number) %>% slice(1)     #1. satırı secer
Titanic_dt %>% select (Class, Sex, Age, Survived, Number) %>% slice(1:3)   #1'den 3'e kadar olan satırları secer
Titanic_dt %>% select (Class, Sex, Age, Survived, Number) %>% slice(5:8)   #5dan 8'e kadar olan satırları secer

Titanic_dt %>% select (Class, Sex, Age, Survived, Number) %>% slice(-1)
Titanic_dt %>% select (Class, Sex, Age, Survived, Number) %>% slice(-3:-32)

#in komutu
Titanic_dt %>%  filter (Class %in% "2nd")

# not in 
Titanic_dt %>%  filter (!Class %in% "2nd")

#between komutu
Titanic_dt %>%  filter (Number %between% c(50, 100))

#veri duzenleme (order)
Titanic_dt %>% arrange (Number) %>% slice (1:5)
Titanic_dt %>% arrange (Number) %>% slice (10)

Titanic_dt %>% arrange (desc(Number)) 

#Filtreleme (Kosullu Veri Secme)
Titanic_dt %>% filter(Survived =="Yes")  
Titanic_dt %>% filter(Survived =="Yes") %>% arrange (desc(Number)) 
Titanic_dt %>% filter(Survived =="Yes") %>% arrange (desc(Number)) %>% slice (1:5)

Titanic_dt %>% filter(Survived =="Yes" & Age=="Adult")
Titanic_dt %>% filter(Class =="1st" | Class =="2nd")

#Tekrarsiz Veri Secme
Titanic_dt %>% arrange (Class) %>% distinct(Class)  #tekrarsiz cekilen sutunu getirir
Titanic_dt %>% arrange (Class) %>% distinct(Class, .keep_all=TRUE)  #tum sutunu getirir

##kolon ekleme/cikarma
#mutate : kolonlar uzerinden islem yapmamizi saglar
Titanic_dt %>% mutate(ClassRatio = NopofClass / Nop)
Titanic_dt %>% mutate(ClassRatio = round(NopofClass/Nop,2))
Titanic_dt %>% mutate(ClassRatio = round(NopofClass/Nop,2)) %>% arrange (desc(ClassRatio))
Titanic_dt %>% mutate(ClassRatio = round(NopofClass/Nop,2)) %>% arrange (desc(ClassRatio)) %>% distinct(Class, ClassRatio)


ClassRat<- Titanic_dt %>% mutate(ClassRatio = round(NopofClass/Nop,2)) %>% arrange (desc(ClassRatio)) %>% distinct(Class, ClassRatio)
SexRat<- Titanic_dt %>% mutate(SexRatio = round(NopofSex/Nop,2)) %>% arrange (desc(SexRatio)) %>% distinct(Sex, SexRatio)
AgeRat<- Titanic_dt %>% mutate(AgeRatio = round(NopofAge/Nop,2)) %>% arrange (desc(AgeRatio)) %>% distinct(Age, AgeRatio)
SurvivedRat<- Titanic_dt %>% mutate(SurvivedRatio = round(NopofSurvived/Nop,2)) %>% arrange (desc(SurvivedRatio)) %>% distinct(Survived, SurvivedRatio)


Titanic_dt %>% mutate(ClassRatio = round(NopofClass/Nop,2),
              SexRatio = round(NopofSex/Nop,2),
              AgeRatio = round(NopofAge/Nop,2),
              SurvivedRatio = round(NopofSurvived/Nop,2))


#veri aggrete etme (mean, sum,max, min)
ClassRat %>% mutate(Total = sum(ClassRatio))
SexRat %>% mutate(Total = sum(SexRatio))
AgeRat %>% mutate(Total = sum(AgeRatio))
SurvivedRat %>% mutate(Total = sum(SurvivedRatio))

ClassRat %>% mutate(MAX = max(ClassRatio)) %>% filter(ClassRatio == MAX)
SexRat %>% mutate(MAX = max(SexRatio)) %>% filter(SexRatio == MAX)
AgeRat %>% mutate(MAX = max(AgeRatio)) %>% filter(AgeRatio == MAX)
SurvivedRat %>% mutate(MAX = max(SurvivedRatio)) %>% filter(SurvivedRatio == MAX)

#farkli yazilis, altt altta yazildiginda  %>%  komutun sonunda olmalidir
new_tt <- Titanic_dt %>% 
          mutate(ClassRatio = round(NopofClass/Nop,2)) %>% 
          arrange (desc(ClassRatio))
new_tt_1 <- new_tt %>% select (-ClassRatio)

new_tt %>% select (-ends_with("Ratio"))
new_tt %>% select (-starts_with("ClassR"))

#kolon adi degistirme
Titanic_dt %>% rename (No = Number) %>%  slice (1)


#transmute
Titanic_dt %>% transmute(Class, ClassRatio = round(NopofClass/Nop,2)) 
Titanic_dt %>% transmute(Class, ClassRatio = round(NopofClass/Nop,2)) %>% distinct(Class, ClassRatio)

#ozet 
Titanic_dt %>% group_by(Class) %>% summarise (NofPassenger=sum(Number))
Titanic_dt %>% group_by(Class, Age) %>% summarise (NofPassenger=sum(Number))
Titanic_dt %>% group_by(Class, Survived) %>% summarise (NofPassenger=sum(Number))



                                     
                                                




















