#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidyverse)
library(plotly)

#####
CHANGE THE PATH
#####
load("/YOURPATHHERE/shiny_movie_set.RData")
genres <- shiny_movie_set %>% distinct(genre) %>% unlist(.)
names(genres) <- NULL

ui <- fluidPage(
   
   # Application title
   titlePanel("Filmlerin Uzunlukları ve IMDB Puanları"),
   
   # Sidebar with a slider input for number of bins 
   sidebarLayout(
      sidebarPanel(
         sliderInput("years",
                     "Yıllar",
                     min = 2000,
                     max = 2005,
                     value = c(2002,2003),sep=""),
         selectInput(inputId="genre",
                     label="Tür",
                     choices=c("Hepsi",sort(genres))),
         sliderInput("votes",
                     "En Az Oy",
                     min = 0,
                     max = 35000,
                     value = 0)
      ),
      
      # Show a plot of the generated distribution
      mainPanel(
         plotlyOutput("moviePlot")
         # plotOutput("moviePlot")
      )
   )
)

server <- function(input, output) {
   
  plot_data <- reactive({
      pl_df <-
      shiny_movie_set %>%
        filter(year >= input$years[1] & 
                 year <= input$years[2] & votes >= input$votes)
      
      if(input$genre != "Hepsi"){
        pl_df <- pl_df %>% filter(genre == input$genre)
      }

      pl_df
  })
  
   # output$moviePlot <- renderPlot({
   #    ggplot(plot_data(),aes(x=length, y=rating)) +
   #     geom_point(aes(color = genre))
   # })
   
   output$moviePlot <- renderPlotly({
     p1<-
     ggplot(plot_data(),aes(x=length, y=rating)) +
       geom_point(aes(color = genre)) 
     
     ggplotly(p1)
   })
}

# Run the application 
shinyApp(ui = ui, server = server)

