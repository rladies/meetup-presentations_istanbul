##########################################################
########### 3.BÖLÜM  - Shiny Dashboard Body  #############
##########################################################


# 1. Kütüphaneler ---------------------------------------------------------

library(shiny)
library(shinydashboard)



# 2. Header Tanımlama -----------------------------------------------------

header <- dashboardHeader(
  title = "R-Ladies İstanbul"
  ) 


# 3. Sidebar ile Menülerin Oluşturulması ----------------------------------

sidebar <- dashboardSidebar( 
  
  sidebarMenu(
    
    menuItem(tabName = "menu1", text = "Menu 1"), 
    
    menuItem(tabName = "menu2", text = "Menu 2", icon = icon("r-project"),
             
             menuSubItem(tabName = "menu2_1", text = "Menu 2.1.")
             ),
    
    menuItem(tabName = "menu3", text = "Menu 3",
             
             menuItem(tabName = "menu3_1", text = "Menu 3.1."),
             
             menuItem(tabName = "menu3_2", text = "Menu 3.2.")
             )
    )
  )


# 4. Body - Tab Item & Tab Box &Tab Panel ---------------------------------

body <- dashboardBody(
  
  tabItems(
    
    tabItem(tabName = "menu1", 
            "Input data here"),
    
    tabItem(tabName = "menu2_1",
            "Look at my cool dashboard"),
    
    tabItem(tabName = "menu3_1",
            
      tabBox(
        title = "My first box",
        tabPanel("Tab1", "Content for the first tab"), 
        tabPanel("Tab2", "Content for the second tab")
        
      )
    )
  )
)



# 5. UI'ın Oluşturulması --------------------------------------------------
ui <- dashboardPage(header, sidebar, body, 
                    skin = "purple")


# 6. Server ---------------------------------------------------------------

server <- function(input, output) {} 


# 7. Shiny App ------------------------------------------------------------

shinyApp(ui = ui, server = server)
