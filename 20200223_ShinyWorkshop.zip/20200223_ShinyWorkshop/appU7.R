#######################################################################
######### 12.BÖLÜM  - Uygulama Active Button & ObserveEvent ###########
#######################################################################

# FIFA Database sekmesi eklenir. 
# Active Button ile inputlar ve outputlar otomatik olarak değil butona tıklandığında değişir.
# Active Button kullanıldığında observe değil observeEvent kullanılır. 

# 1. Kütüphane ------------------------------------------------------------

library(shiny)
library(shinydashboard)
library(tidyverse)
library(plotly)
library(DT)
library(magrittr)


# 2. Header ---------------------------------------------------------------

header <- dashboardHeader(
  title = tagList(icon("r-project"),"- Ladies İstanbul")
) 


# 3. Sidebar --------------------------------------------------------------

sidebar <- dashboardSidebar( 
  
  sidebarMenu(
    
    menuItem(tabName = "tab_home", text = "Home", icon = icon("home")),
    menuItem(tabName = "tab_app", text = "App", icon = icon("rocket"))
  ) 
)


# 4. Body -----------------------------------------------------------------


body <- dashboardBody(
  
  tabItems(
    
# 5. Ana Sayfa ------------------------------------------------------------
    
    tabItem(tabName = "tab_home",
            
            fluidRow(
              column(width = 12,
                     
                     box(title = "R YOU READY?", status = "success", width = NULL,
                         solidHeader = TRUE, collapsible = FALSE,
                         
                         
# 5.1. Başlık -------------------------------------------------------------
                         
                         h4("Bu dashboard R-Ladies 23 Şubat 2020 etkinliği için hazırlanmıştır."),
                         hr(),
                         
                         
# 5.2. Birinci Sütun ------------------------------------------------------
                         
                         column(width = 6,
                                
                                # Başlık
                                h4("R-Ladies"),
                                
                                # R-Ladies Görseli
                                tags$img(src="rladies.PNG", style="width: 90%; height: 50%;"),
                                br(),
                                
                                # Link Ekleme
                                a("R-Ladies Dünya Haritası",
                                  href = "https://rladies.org/directory/")
                         ),
                         
# 5.3. İkinci Sütun -------------------------------------------------------
                         
                         column(width = 6,
                                
                                # Başlık
                                h4("Veri Bilimi Süreci"),
                                
                                # Veri Bilimi Süreci Görseli
                                tags$img(src="datascience.png", style="width: 100%; height: 80%;"),
                                
                                # Link Ekleme
                                a("Veri Bilimi Süreci: Allison Horst Illustrations", 
                                  href="https://github.com/allisonhorst/stats-illustrations/")
                                
                                
                         )
                         
                     )
              )
            )
            
    ),
    
    
    
# 6. App Sayfası ----------------------------------------------------------
    
    tabItem(tabName = "tab_app",
            
            
            fluidRow(
              
              column(width = 12,
                     
                     box(
                       title = "Dashboard", status = "success", width = NULL, 
                       solidHeader = TRUE, collapsible = FALSE,
                       
                       tabsetPanel(type = "pills",
                                   
                                   tabPanel("Data",icon = icon("database"),
                                            
                                            br(),
                                            
                                            fluidRow(
                                              
                                              
# 7. Veri Seti Seçimi -----------------------------------------------------
                                              
                                              column(width = 3,
                                                     selectInput(inputId = "Rdata", label = "Select Data:",
                                                                 choices = c("IRIS", "MTCARS","STORMS"),
                                                                 selected = "IRIS")
                                              ),
                                              
                                              
# 8. Analiz Türü: Tablo | Görselleştirme ----------------------------------
                                              
                                              
                                              column(width = 3,
                                                     selectInput(inputId = "type", label = "Select Analysis:",
                                                                 choices = c("DATA", "VISUALIZATION"),
                                                                 selected = "DATA")
                                              ),
                                              
# 9. Conditional Panel ----------------------------------------------------
                                              
                                              conditionalPanel(condition = "input.type == 'VISUALIZATION'",
                                                               
# Görselleştirme seçeneği sonucunda X ve Y değişkenlerinin seçimi için Select Input'ların eklenmesi
                                                               column(width = 3,
                                                                      selectInput(inputId = "X", label = "Select X Variable:",
                                                                                  choices = NULL)
                                                               ),
                                                               
                                                               column(width = 3,
                                                                      selectInput(inputId = "Y", label = "Select Y Variable:",
                                                                                  choices = NULL)
                                                               )                
                                                               
                                              )
                                              
                                              
                                              
                                            ),
                                            
                                            
                                            fluidRow(
                                              
# Veri seçeneği sonucu Veri, Verinin Yapısı ve Veri Özetinin çıktıları: verbatimTextOutput
                                              conditionalPanel(condition = "input.type == 'DATA'",
                                                               
                                                               column(width = 6,
                                                                      dataTableOutput("data1")
                                                                      
                                                               ),
                                                               
                                                               column(width = 6,
                                                                      verbatimTextOutput("str"),
                                                                      verbatimTextOutput("summary")
                                                               )
                                                               
                                                               
                                              ),
                                              
# Görselleştire seçeneği sonucu görselin ekrana yazdırılması: plotlyOutput                                                
                                              conditionalPanel(condition = "input.type == 'VISUALIZATION'",
                                                               
                                                               column(width = 12,
                                                                      plotlyOutput("plot")
                                                               )
                                                               
                                              )
                                              
                                              
                                              
                                              
                                            )
                                   ),
                                   

# 10. FIFA Database Sekmesi -----------------------------------------------

                                   
                                   tabPanel("FIFA Database",icon = icon("futbol"),
                                            
                                            column(
                                              width = 12,
                                              
                                              fluidRow(
                                                
                                                br(), 
                                                

# 10.1. Active Button -----------------------------------------------------

                                                
                                                actionButton("action", "Start"),
                                                
                                                hr(),
                                                
                                                dataTableOutput("database")
                                                
                                              )
                                              
                                            )
                                            
                                            
                                   )
                                   
                                   
                                   
                                   
                       )
                       
                       
                     )
              )
              
            )
            
            
            
    )
    
    
  )
  
)

                                     
                                     

# 11. UI ------------------------------------------------------------------

ui <- dashboardPage(header, sidebar, body, 
                    skin = "purple",
                    
                    tags$head(
                      tags$style(
                        HTML(
                        "
                        .skin-purple .main-header .navbar {
                        background-color: #88398a;}

                        .skin-purple .main-header .logo {
                        background-color: #88398a;
                        color: #fff;
                        border-bottom: 0 solid transparent;
                        }
                        
                        .skin-purple .sidebar-menu>li.active>a, .skin-purple .sidebar-menu>li:hover>a {
                        color: #fff;
                        background: #1e282c;
                        border-left-color: #88398a;
                        }
                        
                        .box.box-solid.box-success>.box-header {
                        color: #fff;
                        background: #88398a;
                        background-color: #88398a;
                        }
                        
                        .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
                        border-top-color: #562427;
                        }
                        
                        .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
                        color: #fff;
                        background-color: darkgray;
                        }
                        
                        "
                         )
                       )
                      )
                    
                    )


# 12. Server --------------------------------------------------------------

server <- function(input, output, session) {
  
# 13. Data Sayfası --------------------------------------------------------
  
  # Reactive Values
  rv <- reactiveValues(data = NULL)
  
  observe({
    
    if(input$Rdata == "IRIS"){
      
      df <- iris
      
    }else if(input$Rdata == "MTCARS"){
      
      df <- mtcars
      
      
    }else if(input$Rdata == "STORMS"){
      
      df <- storms

    }else{
      
      return(NULL)
    }
    
    rv$data <- df
    
  })
  
  output$data1 <- renderDataTable({
    
    datatable(rv$data, options = list(scrollX = TRUE))
    
  })
  
  output$data2 <- renderTable({
    
    rv$data %>% head(20)
    
  })
  
  output$str <- renderPrint({
    
    str(rv$data)
    
  })
  
  output$summary <- renderPrint({
    
    summary(rv$data)
    
  })
  
  # Reaktif Olarak Input Ekleme
  observe({
    updateSelectInput(session, "X", choices = names(rv$data))
  })
  
  observe({
    updateSelectInput(session, "Y", choices = names(rv$data), selected = names(rv$data)[2])
  })
  

  output$plot <- renderPlotly({
    
    ggplotly(
      ggplot(rv$data, aes(x = !!rlang::parse_expr(input$X), y = !!rlang::parse_expr(input$Y)))+
        geom_point(shape = 21, fill = "pink", color = "royalblue", size = 3)+
        geom_smooth(se = FALSE, color = "purple")+
        theme_minimal()
    )
    
  })
  


# 13. FIFA Database Sekmesi -----------------------------------------------

  # Reaktif Values
  rvLeague <- reactiveValues(Fifa = NULL)
  

# 13.1. Observe Event -----------------------------------------------------

  observeEvent(input$action, {
    
    # Data
    df <- read.csv("data.csv", encoding = "UTF-8")[,-1:-2]
    
    # League Değişkeninin Oluşturulması: Premier League - La Liga
    premierLeague <- c(
      "Arsenal", "Bournemouth", "Brighton & Hove Albion", "Burnley",
      "Cardiff City", "Chelsea", "Crystal Palace", "Everton", "Fulham",
      "Huddersfield Town", "Leicester City", "Liverpool", "Manchester City",
      "Manchester United", "Newcastle United", "Southampton", 
      "Tottenham Hotspur", "Watford", "West Ham United", "Wolverhampton Wanderers"
      
    )
    
    laliga <- c(
      "Athletic Club de Bilbao", "Atlético Madrid", "CD Leganés",
      "Deportivo Alavés", "FC Barcelona", "Getafe CF", "Girona FC", 
      "Levante UD", "Rayo Vallecano", "RC Celta", "RCD Espanyol", 
      "Real Betis", "Real Madrid", "Real Sociedad", "Real Valladolid CF",
      "SD Eibar", "SD Huesca", "Sevilla FC", "Valencia CF", "Villarreal CF"
    )
    
    
    df %<>% mutate(League = if_else(Club %in% premierLeague, "Premier League",
                                    if_else(Club %in% laliga, "La Liga", NA_character_)))
    
    # Reaktif Veri Setinin Oluşturulması
    rvLeague$Fifa <- df
    
    
    # FIFA Veri Tabanı: DataTable 
    output$database <- renderDT({
      
      datatable(rvLeague$Fifa, options = list(scrollX = TRUE))
    })
    
    
    
  })
  
  

# 13.2. League Select Input Reaktif Observe -------------------------------

  observe({
    updateSelectInput(session, "league", choices = sort(unique(rvLeague$Fifa$League)))
  })
  
  
  
} 


# 14. Shiny App -----------------------------------------------------------

shinyApp(ui = ui, server = server)
