#######################################################################
######### 13.BÖLÜM  - Uygulama observeEvent ve Select Input ###########
#######################################################################

# League sayfası oluşturulur. Fakat FIFA Database sayfasındaki action button bir başlangıç butonu olarak tasarlandığı için
# action butona'a tıklanmadığından League sayfası işlevsizdir.

# Select Input değiştirildiğinde action button'a tıklanmadığında çıktılar gözükmez! 

# Ligin en iyi 11'in oluşturulması ve ligde oynayan oyuncuların ülkelerinin görselleştirilmesi!



# 1. Kütüphaneler ---------------------------------------------------------

library(shiny)
library(shinydashboard)
library(shinyWidgets)
library(tidyverse)
library(plotly)
library(DT)
library(maps)
library(magrittr)


# 2. Header ---------------------------------------------------------------

header <- dashboardHeader(
  title = tagList(icon("r-project"),"- Ladies İstanbul")
) 


# 3. Sidebar --------------------------------------------------------------

sidebar <- dashboardSidebar( 
  
  sidebarMenu(
    
    menuItem(tabName = "tab_home", text = "Home", icon = icon("home")),
    menuItem(tabName = "tab_app", text = "App", icon = icon("rocket"))
  ) 
)


# 4. Body -----------------------------------------------------------------


body <- dashboardBody(
  
  tabItems(
    
# 5. Ana Sayfa ------------------------------------------------------------
    
    tabItem(tabName = "tab_home",
            
            fluidRow(
              column(width = 12,
                     
                     box(title = "R YOU READY?", status = "success", width = NULL,
                         solidHeader = TRUE, collapsible = FALSE,
                         
                         
# 5.1. Başlık -------------------------------------------------------------
                         
                         h4("Bu dashboard R-Ladies 23 Şubat 2020 etkinliği için hazırlanmıştır."),
                         hr(),
                         
                         
# 5.2. Birinci Sütun ------------------------------------------------------
                         
                         column(width = 6,
                                
                                # Başlık
                                h4("R-Ladies"),
                                
                                # R-Ladies Görseli
                                tags$img(src="rladies.PNG", style="width: 90%; height: 50%;"),
                                br(),
                                
                                # Link Ekleme
                                a("R-Ladies Dünya Haritası",
                                  href = "https://rladies.org/directory/")
                         ),
                         
# 5.3. İkinci Sütun -------------------------------------------------------
                         
                         column(width = 6,
                                
                                # Başlık
                                h4("Veri Bilimi Süreci"),
                                
                                # Veri Bilimi Süreci Görseli
                                tags$img(src="datascience.png", style="width: 100%; height: 80%;"),
                                
                                # Link Ekleme
                                a("Veri Bilimi Süreci: Allison Horst Illustrations", 
                                  href="https://github.com/allisonhorst/stats-illustrations/")
                                
                                
                         )
                         
                     )
              )
            )
            
    ),
    
    
    
# 6. App Sayfası ----------------------------------------------------------
    
    tabItem(tabName = "tab_app",
            
            
            fluidRow(
              
              column(width = 12,
                     
                     box(
                       title = "Dashboard", status = "success", width = NULL, 
                       solidHeader = TRUE, collapsible = FALSE,
                       
                       tabsetPanel(type = "pills",
                                   
                                   tabPanel("Data",icon = icon("database"),
                                            
                                            br(),
                                            
                                            fluidRow(
                                              
                                              
# 7. Veri Seti Seçimi -----------------------------------------------------
                                              
                                              column(width = 3,
                                                     selectInput(inputId = "Rdata", label = "Select Data:",
                                                                 choices = c("IRIS", "MTCARS","STORMS"),
                                                                 selected = "IRIS")
                                              ),
                                              
                                              
# 8. Analiz Türü: Tablo | Görselleştirme ----------------------------------
                                              
                                              
                                              column(width = 3,
                                                     selectInput(inputId = "type", label = "Select Analysis:",
                                                                 choices = c("DATA", "VISUALIZATION"),
                                                                 selected = "DATA")
                                              ),
                                              
# 9. Conditional Panel ----------------------------------------------------
                                              
                                              conditionalPanel(condition = "input.type == 'VISUALIZATION'",
                                                               
# Görselleştirme seçeneği sonucunda X ve Y değişkenlerinin seçimi için Select Input'ların eklenmesi
                                                               column(width = 3,
                                                                      selectInput(inputId = "X", label = "Select X Variable:",
                                                                                  choices = NULL)
                                                               ),
                                                               
                                                               column(width = 3,
                                                                      selectInput(inputId = "Y", label = "Select Y Variable:",
                                                                                  choices = NULL)
                                                               )                
                                                               
                                              )
                                              
                                              
                                              
                                            ),
                                            
                                            
                                            fluidRow(
                                              
# Veri seçeneği sonucu Veri, Verinin Yapısı ve Veri Özetinin çıktıları: verbatimTextOutput
                                              conditionalPanel(condition = "input.type == 'DATA'",
                                                               
                                                               column(width = 6,
                                                                      dataTableOutput("data1")
                                                                      
                                                               ),
                                                               
                                                               column(width = 6,
                                                                      verbatimTextOutput("str"),
                                                                      verbatimTextOutput("summary")
                                                               )
                                                               
                                                               
                                              ),
                                              
# Görselleştire seçeneği sonucu görselin ekrana yazdırılması: plotlyOutput                                                
                                              conditionalPanel(condition = "input.type == 'VISUALIZATION'",
                                                               
                                                               column(width = 12,
                                                                      plotlyOutput("plot")
                                                               )
                                                               
                                              )
                                              
                                              
                                              
                                              
                                            )
                                   ),
                                   
                                   
# 10. FIFA Database Sekmesi -----------------------------------------------
                                   
                                   
                                   tabPanel("FIFA Database",icon = icon("futbol"),
                                            
                                            column(
                                              width = 12,
                                              
                                              fluidRow(
                                                
                                                br(), 
                                                
                                                
# 10.1. Active Button -----------------------------------------------------
                                                
                                                
                                                actionButton("action", "Start"),
                                                
                                                hr(),
                                                
                                                dataTableOutput("database")
                                                
                                              )
                                              
                                            )
                                            
                                            
                                   ),
                                   

# 11. League Sekmesi ------------------------------------------------------
          
                                   tabPanel("League", icon = icon("trophy"),
                                            
                                            br(),
                                            
                                            selectInput(inputId = "league", label = "Select League:",
                                                        choices = "", width = "20%"),
                                            
                                            actionButton(inputId = "select_league", label = "Select"),
                                            
                                            hr(),
                                            
                                            column(width = 6, 
                                                   tableOutput("best_team")
                                            ),
                                            
                                            column(width = 6, 
                                                   plotlyOutput("league_nat1")
                                            )
                                            
                                            
                                   )
                                   
                                   
                                   
                                   
                       )
                       
                       
                     )
              )
              
            )
            
            
            
    )
    
    
  )
  
)




# 12. UI ------------------------------------------------------------------

ui <- dashboardPage(header, sidebar, body, 
                    skin = "purple",
                    
                    tags$head(
                      tags$style(
                        HTML(
                          "
                        .skin-purple .main-header .navbar {
                        background-color: #88398a;}

                        .skin-purple .main-header .logo {
                        background-color: #88398a;
                        color: #fff;
                        border-bottom: 0 solid transparent;
                        }
                        
                        .skin-purple .sidebar-menu>li.active>a, .skin-purple .sidebar-menu>li:hover>a {
                        color: #fff;
                        background: #1e282c;
                        border-left-color: #88398a;
                        }
                        
                        .box.box-solid.box-success>.box-header {
                        color: #fff;
                        background: #88398a;
                        background-color: #88398a;
                        }
                        
                        .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
                        border-top-color: #562427;
                        }
                        
                        .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
                        color: #fff;
                        background-color: darkgray;
                        }
                        
                        "
                        )
                      )
                    )
                    
)



# 13. Server --------------------------------------------------------------


server <- function(input, output, session) {
  

# 13.1. Data Sekmesi ------------------------------------------------------

  # Reactive Values
  rv <- reactiveValues(data = NULL)
  
  observe({
    
    if(input$Rdata == "IRIS"){
      
      df <- iris
      
    }else if(input$Rdata == "MTCARS"){
      
      df <- mtcars
      
      
    }else if(input$Rdata == "STORMS"){
      
      df <- storms

    }else{
      
      return(NULL)
    }
    
    rv$data <- df
    
  })
  
  output$data1 <- renderDataTable({
    
    datatable(rv$data, options = list(scrollX = TRUE))
    
  })
  
  output$data2 <- renderTable({
    
    rv$data %>% head(20)
    
  })
  
  output$str <- renderPrint({
    
    str(rv$data)
    
  })
  
  output$summary <- renderPrint({
    
    summary(rv$data)
    
  })
  
  # Reaktif Olarak Input Ekleme
  observe({
    updateSelectInput(session, "X", choices = names(rv$data))
  })
  
  observe({
    updateSelectInput(session, "Y", choices = names(rv$data), selected = names(rv$data)[2])
  })
  

  output$plot <- renderPlotly({
    
    ggplotly(
      ggplot(rv$data, aes(x = !!rlang::parse_expr(input$X), y = !!rlang::parse_expr(input$Y)))+
        geom_point(shape = 21, fill = "pink", color = "royalblue", size = 3)+
        geom_smooth(se = FALSE, color = "purple")+
        theme_minimal()
    )
    
  })
  


# 13.2. League Sekmesi ----------------------------------------------------
  
  rvDatabase <- reactiveValues(Fifa = NULL)
  
  observeEvent(input$action, {
    
    df <- read.csv("data.csv", encoding = "UTF-8")[,-1:-2]
    
    premierLeague <- c(
      "Arsenal", "Bournemouth", "Brighton & Hove Albion", "Burnley",
      "Cardiff City", "Chelsea", "Crystal Palace", "Everton", "Fulham",
      "Huddersfield Town", "Leicester City", "Liverpool", "Manchester City",
      "Manchester United", "Newcastle United", "Southampton", 
      "Tottenham Hotspur", "Watford", "West Ham United", "Wolverhampton Wanderers"
      
    )
    
    laliga <- c(
      "Athletic Club de Bilbao", "Atlético Madrid", "CD Leganés",
      "Deportivo Alavés", "FC Barcelona", "Getafe CF", "Girona FC", 
      "Levante UD", "Rayo Vallecano", "RC Celta", "RCD Espanyol", 
      "Real Betis", "Real Madrid", "Real Sociedad", "Real Valladolid CF",
      "SD Eibar", "SD Huesca", "Sevilla FC", "Valencia CF", "Villarreal CF"
    )
    
    df %<>% mutate(League = if_else(Club %in% premierLeague, "Premier League",
                                    if_else(Club %in% laliga, "La Liga", NA_character_)))
    
    rvDatabase$Fifa <- df
    
# Send Sweet Alert --------------------------------------------------------
    
    sendSweetAlert(session = session, type = "success", closeOnClickOutside = FALSE, btn_labels = "Ok",
                   title = "FIFA Leagues", text = "You can choose Premier League & La Liga."   )
    
    output$database <- renderDT({
      
      datatable(rvDatabase$Fifa, options = list(scrollX = TRUE))
    })
    
    
  })


  observe({
    updateSelectInput(session, "league", choices = sort(unique(rvDatabase$Fifa$League)))
  })
  
  

# 13.3. League Sekmesi ----------------------------------------------------

  # League Select Input için reaktif oluşturulur.
  rvLeague <- reactiveValues(League = NULL)
  
  
  # Select Input değiştiğinde action buttona tıklandıktan sonra output değişir.
  observeEvent(input$select_league, {
    
    # req fonksiyonu inputun zorunlu olduğundu belirtir.
    req(input$league)
    rvLeague$League <- input$league
    
    
    # Lig'in en iyi 11'inin hesaplanması
    output$best_team <- renderTable({
      
      bestTeam <- rvDatabase$Fifa %>% 
        filter(League %in% rvLeague$League)
      
      team <- tibble()
      team_copy <- bestTeam %>% 
        select(Jersey.Number, Name, Overall, Position, Club) %>%
        arrange(-Overall)
      
      tac442 <- c("GK","RB", "CB", "CB", "LB", "RM", "CM", "CM", "LM", "ST", "ST")
      
      for (i in tac442) {
        
        team %<>%  bind_rows(team_copy %>% filter(Position %in% i) %>% head(1))
        team_copy %<>% filter(!Name %in% (team %>% pull(Name)))
        
      }
      
      team %>%
        add_row(Name = "Average Overall:", Overall = round(mean(team$Overall), digits = 2), Position = "ALL") %>%
        mutate(Jersey.Number = as.character(Jersey.Number),
               Club = as.character(Club),
               Jersey.Number = if_else(is.na(Jersey.Number), "", Jersey.Number),
               Club = if_else(is.na(Club), "", Club)) %>%
        rename_all(funs(gsub("[[:punct:]]", " ", .)))
      
    })
    
    
    # Dünya haritası görselinin oluştururlması: Plotly ve ggplot
    output$league_nat1 <-  renderPlotly({
      
      world_map <- map_data("world")
      
      numofplayers <- world_map %>% mutate(region = as.character(region)) %>% 
        left_join((rvDatabase$Fifa %>% 
                     filter(League == rvLeague$League) %>%
                     mutate(Nationality = as.character(Nationality),
                            Nationality = if_else(Nationality %in% "England", "UK", Nationality)) %>% 
                     count(Nationality, name = "Number of Player") %>%
                     rename(region = Nationality) %>%
                     mutate(region = as.character(region))), by = "region")
      
      ggplotly(
        ggplot(numofplayers, aes(long, lat, group = group))+
          geom_polygon(aes(fill = `Number of Player` ), color = "white", show.legend = FALSE)+
          scale_fill_viridis_c(option = "C")+
          theme_void()+
          labs(fill = "Number of Players",
               title = "Nationality of The Players in The League"))
      
    })
    
    
  })
  

  
} 


# 14. Shiny App -----------------------------------------------------------

shinyApp(ui = ui, server = server)
