#######################################################################
##################### 11.BÖLÜM  - Uygulama Reaktif 2 ##################
#######################################################################

# Conditional Panel, Veri Görselleştirme

# 1. Kütüphane ------------------------------------------------------------

library(shiny)
library(shinydashboard)
library(tidyverse)
library(plotly)
library(DT)


# 2. Header ---------------------------------------------------------------

header <- dashboardHeader(
  title = tagList(icon("r-project"),"- Ladies İstanbul")
) 


# 3. Sidebar --------------------------------------------------------------

sidebar <- dashboardSidebar( 
  
  sidebarMenu(
    
    menuItem(tabName = "tab_home", text = "Home", icon = icon("home")),
    menuItem(tabName = "tab_app", text = "App", icon = icon("rocket"))
  ) 
)


# 4. Body -----------------------------------------------------------------

body <- dashboardBody(
  
  tabItems(
    
    # 5. Ana Sayfa ------------------------------------------------------------
    
    tabItem(tabName = "tab_home",
            
            fluidRow(
              column(width = 12,
                     
                     box(title = "R YOU READY?", status = "success", width = NULL,
                         solidHeader = TRUE, collapsible = FALSE,
                         
                         
                         # 5.1. Başlık -------------------------------------------------------------
                         
                         h4("Bu dashboard R-Ladies 23 Şubat 2020 etkinliği için hazırlanmıştır."),
                         hr(),
                         
                         
                         # 5.2. Birinci Sütun ------------------------------------------------------
                         
                         column(width = 6,
                                
                                # Başlık
                                h4("R-Ladies"),
                                
                                # R-Ladies Görseli
                                tags$img(src="rladies.PNG", style="width: 90%; height: 50%;"),
                                br(),
                                
                                # Link Ekleme
                                a("R-Ladies Dünya Haritası",
                                  href = "https://rladies.org/directory/")
                         ),
                         
                         # 5.3. İkinci Sütun -------------------------------------------------------
                         
                         column(width = 6,
                                
                                # Başlık
                                h4("Veri Bilimi Süreci"),
                                
                                # Veri Bilimi Süreci Görseli
                                tags$img(src="datascience.png", style="width: 100%; height: 80%;"),
                                
                                # Link Ekleme
                                a("Veri Bilimi Süreci: Allison Horst Illustrations", 
                                  href="https://github.com/allisonhorst/stats-illustrations/")
                                
                                
                         )
                         
                     )
              )
            )
            
    ),
    
    
    
# 6. App Sayfası ----------------------------------------------------------
    
    tabItem(tabName = "tab_app",
            
            
            fluidRow(
              
              column(width = 12,
                     
                     box(
                         title = "Dashboard", status = "success", width = NULL, 
                         solidHeader = TRUE, collapsible = FALSE,
                         
                         tabsetPanel(type = "pills",
                                     
                                     tabPanel("Data",icon = icon("database"),
                                              
                                              br(),
                                              
                                              fluidRow(
                                                

# 7. Veri Seti Seçimi -----------------------------------------------------

                                                column(width = 3,
                                                       selectInput(inputId = "Rdata", label = "Select Data:",
                                                                   choices = c("IRIS", "MTCARS","STORMS"),
                                                                   selected = "IRIS")
                                                ),


# 8. Analiz Türü: Tablo | Görselleştirme ----------------------------------

                                                
                                                column(width = 3,
                                                       selectInput(inputId = "type", label = "Select Analysis:",
                                                                   choices = c("DATA", "VISUALIZATION"),
                                                                   selected = "DATA")
                                                ),

# 9. Conditional Panel ----------------------------------------------------

                                                conditionalPanel(condition = "input.type == 'VISUALIZATION'",
                                                 
# Görselleştirme seçeneği sonucunda X ve Y değişkenlerinin seçimi için Select Input'ların eklenmesi
                                                                 column(width = 3,
                                                                        selectInput(inputId = "X", label = "Select X Variable:",
                                                                                    choices = NULL)
                                                                 ),
                                                                 
                                                                 column(width = 3,
                                                                        selectInput(inputId = "Y", label = "Select Y Variable:",
                                                                                    choices = NULL)
                                                                 )                
                                                                 
                                                )
                                                
                                                
                                                
                                              ),
                                              
                                              
                                              fluidRow(
                                                
# Veri seçeneği sonucu Veri, Verinin Yapısı ve Veri Özetinin çıktıları: verbatimTextOutput
                                                conditionalPanel(condition = "input.type == 'DATA'",
                                                                 
                                                                 column(width = 6,
                                                                        dataTableOutput("data1")
                                                                        
                                                                 ),
                                                                 
                                                                 column(width = 6,
                                                                        verbatimTextOutput("str"),
                                                                        verbatimTextOutput("summary")
                                                                 )
                                                                 
                                                                 
                                                                 ),
                                                
# Görselleştire seçeneği sonucu görselin ekrana yazdırılması: plotlyOutput                                                
                                                conditionalPanel(condition = "input.type == 'VISUALIZATION'",
                                                                 
                                                                 column(width = 12,
                                                                   plotlyOutput("plot")
                                                                 )
                                                                 
                                                                 )

                                                
                                                
                                              
                                                )
                                              )
                                              
                                              
                                     
                         
                         )
                         
                         
                       )
                     )
                     
              )
            
            
            
            )
    
    
  )
  
)



# 10. UI ------------------------------------------------------------------

ui <- dashboardPage(header, sidebar, body, 
                    skin = "purple",
                    
                    tags$head(
                      tags$style(
                        HTML(
                        "
                        .skin-purple .main-header .navbar {
                        background-color: #88398a;}

                        .skin-purple .main-header .logo {
                        background-color: #88398a;
                        color: #fff;
                        border-bottom: 0 solid transparent;
                        }
                        
                        .skin-purple .sidebar-menu>li.active>a, .skin-purple .sidebar-menu>li:hover>a {
                        color: #fff;
                        background: #1e282c;
                        border-left-color: #88398a;
                        }
                        
                        .box.box-solid.box-success>.box-header {
                        color: #fff;
                        background: #88398a;
                        background-color: #88398a;
                        }
                        
                        .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
                        border-top-color: #562427;
                        }
                        
                        .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
                        color: #fff;
                        background-color: darkgray;
                        }
                        
                        "
                         )
                       )
                      )
                    
                    )


# 11. Server --------------------------------------------------------------

server <- function(input, output, session) {
  


# 12. Data Sayfası --------------------------------------------------------


# 12.1. Çıktılar ----------------------------------------------------------

  # Reactive Values
  rv <- reactiveValues(data = NULL)
  
  # Observe
  observe({
    
    if(input$Rdata == "IRIS"){
      
      df <- iris
      
    }else if(input$Rdata == "MTCARS"){
      
      df <- mtcars
      
      
    }else if(input$Rdata == "STORMS"){
      
      df <- storms

    }else{
      
      return(NULL)
    }
    
    rv$data <- df
    
  })
  
  # Data Table
  
  output$data1 <- renderDataTable({
    
    datatable(rv$data, options = list(scrollX = TRUE))
    
  })
  
  
  # Verinin Yapısı: verbatimTextOutput
  output$str <- renderPrint({
    
    str(rv$data)
    
  })
  
  # Verinin Özeti: verbatimTextOutput
  output$summary <- renderPrint({
    
    summary(rv$data)
    
  })
  
  

# 12.2. Reaktif Input -----------------------------------------------------

  observe({
    updateSelectInput(session, "X", choices = names(rv$data))
  })
  
  observe({
    updateSelectInput(session, "Y", choices = names(rv$data), selected = names(rv$data)[2])
  })
  
  

# 12.3. ggplot'u plotly çıktısına dönüştürmek -----------------------------

  output$plot <- renderPlotly({
    
    ggplotly(
      ggplot(rv$data, aes(x = !!rlang::parse_expr(input$X), y = !!rlang::parse_expr(input$Y)))+
        geom_point(shape = 21, fill = "pink", color = "royalblue", size = 3)+
        geom_smooth(se = FALSE, color = "purple")+
        theme_minimal()
    )
    
  })
  
  
} 


# 13. Shiny App -----------------------------------------------------------

shinyApp(ui = ui, server = server)
