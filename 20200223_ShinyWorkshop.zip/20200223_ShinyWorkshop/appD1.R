########################################################
########### 1.BÖLÜM  - Shiny Dashboard Giriş ###########
########################################################


# 1. Kütüphaneler ---------------------------------------------------------

library(shiny)
library(shinydashboard)


# 2. Boş Dashboard Oluşturma ----------------------------------------------

### Boş Header Oluşturma
header <- dashboardHeader() 

### Boş Sidebar Oluşturma
sidebar <- dashboardSidebar() 

### Boş Body Oluşturma
body <- dashboardBody()


# 3. UI'ın Oluşturulması --------------------------------------------------

### Header, Sidebar ve Body Bir Araya Getirilir
ui <- dashboardPage(header, sidebar, body)


# 4. Server Oluşturulması -------------------------------------------------

server <- function(input, output) {} 


# 5. Shiny Uygulaması -----------------------------------------------------

shinyApp(ui = ui, server = server)


