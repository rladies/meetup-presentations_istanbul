#######################################################################
##################### 10.BÖLÜM  - Uygulama Reaktif ####################
#######################################################################

# reactiveValues ve Observe anlatılacaktır.

# 1. Kütüphane ------------------------------------------------------------

library(shiny)
library(shinydashboard)
library(tidyverse)
library(DT)


# 2. Header ---------------------------------------------------------------

header <- dashboardHeader(
  title = tagList(icon("r-project"),"- Ladies İstanbul")
) 


# 3. Sidebar --------------------------------------------------------------

sidebar <- dashboardSidebar( 
  
  sidebarMenu(
    
    menuItem(tabName = "tab_home", text = "Home", icon = icon("home")),
    menuItem(tabName = "tab_app", text = "App", icon = icon("rocket"))
  ) 
)


# 4. Body -----------------------------------------------------------------

body <- dashboardBody(
  
  tabItems(
    
    # 5. Ana Sayfa ------------------------------------------------------------
    
    tabItem(tabName = "tab_home",
            
            fluidRow(
              column(width = 12,
                     
                     box(title = "R YOU READY?", status = "success", width = NULL,
                         solidHeader = TRUE, collapsible = FALSE,
                         
                         
                         # 5.1. Başlık -------------------------------------------------------------
                         
                         h4("Bu dashboard R-Ladies 23 Şubat 2020 etkinliği için hazırlanmıştır."),
                         hr(),
                         
                         
                         # 5.2. Birinci Sütun ------------------------------------------------------
                         
                         column(width = 6,
                                
                                # Başlık
                                h4("R-Ladies"),
                                
                                # R-Ladies Görseli
                                tags$img(src="rladies.PNG", style="width: 90%; height: 50%;"),
                                br(),
                                
                                # Link Ekleme
                                a("R-Ladies Dünya Haritası",
                                  href = "https://rladies.org/directory/")
                         ),
                         
                         # 5.3. İkinci Sütun -------------------------------------------------------
                         
                         column(width = 6,
                                
                                # Başlık
                                h4("Veri Bilimi Süreci"),
                                
                                # Veri Bilimi Süreci Görseli
                                tags$img(src="datascience.png", style="width: 100%; height: 80%;"),
                                
                                # Link Ekleme
                                a("Veri Bilimi Süreci: Allison Horst Illustrations", 
                                  href="https://github.com/allisonhorst/stats-illustrations/")
                                
                                
                         )
                         
                     )
              )
            )
            
    ),
    
    
    
    # 6. App Sayfası ----------------------------------------------------------
    
    
    tabItem(tabName = "tab_app",
            
            
            fluidRow(
              
              column(width = 12,
                     
                     box(
                       title = "Dashboard", status = "success", width = NULL, 
                       solidHeader = TRUE, collapsible = FALSE,
                       
                       tabsetPanel(type = "pills",
                                   
                                   tabPanel("Data",icon = icon("database"),
                                            
                                            
                                            # Select Input
                                            selectInput(inputId = "Rdata", label = "Select Data:",
                                                        choices = c("IRIS", "MTCARS", 
                                                                    "STORMS", "STARWARS"),
                                                        selected = "STARWARS"),
                                            
                                            # Data Table  
                                            dataTableOutput("data1"),
                                            
                                            # Table
                                            tableOutput("data2"))
                                   
                                   
                       )
                       
                       
                     )
              )
              
            )
            
            
            
    )
    
    
  )
  
)


# 7. UI -------------------------------------------------------------------
ui <- dashboardPage(header, sidebar, body, 
                    skin = "purple",
                    
                    tags$head(
                      tags$style(
                        HTML(
                        "
                        .skin-purple .main-header .navbar {
                        background-color: #88398a;}

                        .skin-purple .main-header .logo {
                        background-color: #88398a;
                        color: #fff;
                        border-bottom: 0 solid transparent;
                        }
                        
                        .skin-purple .sidebar-menu>li.active>a, .skin-purple .sidebar-menu>li:hover>a {
                        color: #fff;
                        background: #1e282c;
                        border-left-color: #88398a;
                        }
                        
                        .box.box-solid.box-success>.box-header {
                        color: #fff;
                        background: #88398a;
                        background-color: #88398a;
                        }
                        
                        .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
                        border-top-color: #562427;
                        }
                        
                        .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
                        color: #fff;
                        background-color: darkgray;
                        }
                        
                        "
                         )
                       )
                      )
                    
                    )


# 8. Server ---------------------------------------------------------------

server <- function(input, output, session) {
  


# 9. Reactive Values ------------------------------------------------------

  rv <- reactiveValues(data = NULL)
  

# 10. Observe -------------------------------------------------------------

  observe({
    
    if(input$Rdata == "IRIS"){
      
      df <- iris
      
    }else if(input$Rdata == "MTCARS"){
      
      df <- mtcars
      
      
    }else if(input$Rdata == "STORMS"){
      
      df <- storms
      
    }else if(input$Rdata == "STARWARS"){
      
      df <- starwars
      
    }else{
      
      return(NULL)
    }
    
    # Data Frame Reaktif Hale Getirilir
    rv$data <- df
    
  })
  
  

# 11. Datatable ve Table --------------------------------------------------

  output$data1 <- renderDataTable({
    
    rv$data
    
  })
  
  output$data2 <- renderTable({
    
    rv$data %>% head(20)
    
  })
  
  
} 


# 12. Shiny App -----------------------------------------------------------

shinyApp(ui = ui, server = server)
