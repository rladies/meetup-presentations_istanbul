##########################################################
########### 2.BÖLÜM  - Shiny Dashboard Giriş 2 ###########
##########################################################

# 1. Kütüphaneler ---------------------------------------------------------

library(shiny)
library(shinydashboard)




# 2. Header Tanımlama -----------------------------------------------------

header <- dashboardHeader(
  title = "R-Ladies İstanbul"
  ) 



# 3. Sidebar ile Menülerin Oluşturulması ----------------------------------

sidebar <- dashboardSidebar( 

  sidebarMenu(
    
    menuItem(tabName = "menu1", text = "Menu 1"), 
  
    menuItem(tabName = "menu2", text = "Menu 2", icon = icon("r-project"),
             menuSubItem(tabName = "menu2_1", text = "Menu 2.1.")
             ),
  
    menuItem(tabName = "menu3", text = "Menu 2",
             menuItem(tabName = "menu3_1", text = "Menu 3.1.")
             )
  ) 
)


# 4. Icons ----------------------------------------------------------------

# https://shiny.rstudio.com/reference/shiny/0.14/icon.html
# https://fontawesome.com/icons?from=io
# https://getbootstrap.com/docs/4.4/components/alerts/



# 5. Body -----------------------------------------------------------------


body <- dashboardBody()



# 6. UI'ın Oluşturulması --------------------------------------------------

### Header, Sidebar ve Body Bir Araya Getirilir
ui <- dashboardPage(header, sidebar, body, 
                    skin = "purple",
                    

# 7. HTML ve CSS ----------------------------------------------------------
                    
                    # HTML ile Renklendirme
                    
                    # tags$head(
                    #   tags$style(
                    #     HTML(
                    #     "
                    #     .skin-purple .main-header .navbar {
                    #     background-color: #88398a;}
                    # 
                    #     .skin-purple .main-header .logo {
                    #     background-color: #88398a;
                    #     color: #fff;
                    #     border-bottom: 0 solid transparent;
                    #     }
                    #     "
                    #      )
                    #    )
                    #   )
                    
                    )


# 8. Server ---------------------------------------------------------------

server <- function(input, output) {} 


# 9. Shiny App ------------------------------------------------------------

shinyApp(ui = ui, server = server)
