#######################################################################
############## 7.BÖLÜM  - Uygulama Box ve Tabsetpanel   ###############
#######################################################################

# Body'de tabloların ve sayfaların oluşturulması.

# 1. Kütüphaneler ---------------------------------------------------------

library(shiny)
library(shinydashboard)


# 2. Veri -----------------------------------------------------------------

df <- read.csv("data.csv", encoding = "UTF-8")[,-1:-2]



# 3. Header ---------------------------------------------------------------

header <- dashboardHeader(
  title = tagList(icon("r-project"),"- Ladies İstanbul")
) 


# 4. Sidebar --------------------------------------------------------------

sidebar <- dashboardSidebar( 
  
  sidebarMenu(
    menuItem(tabName = "tab_home", text = "Home", icon = icon("home")),
    menuItem(tabName = "tab_app",  text = "App", icon = icon("rocket"))
  ) 
)


# 5. Body -----------------------------------------------------------------

body <- dashboardBody(
  
  tabItems(
    
    tabItem(tabName = "tab_home",
            
            column(width = 12,
                   

# 6. Box ------------------------------------------------------------------

                   box(title = "R YOU READY?", status = "success", width = NULL,
                       solidHeader = TRUE, collapsible = FALSE))
            
            ),
    
    tabItem(tabName = "tab_app",
            
            
            column(width = 12,
                   
                   fluidRow(
                     
                     box(
                       title = "Dashboard", status = "success", width = NULL,
                       solidHeader = TRUE, collapsible = FALSE,
                       

# 7. Tabsetpanel ----------------------------------------------------------

                       tabsetPanel(type = "pills",
                                   
                                   tabPanel("Basics")
                       )
                       
                       )
                     )
                   
                   )
            
            
            )
    
    
  )
  
)



# 8. UI -------------------------------------------------------------------

ui <- dashboardPage(header, sidebar, body, 
                    skin = "purple",
                    

# 9. HTML & CSS -----------------------------------------------------------

                    tags$head(
                      tags$style(
                        HTML(
                        "
                        .skin-purple .main-header .navbar {
                        background-color: #88398a;}

                        .skin-purple .main-header .logo {
                        background-color: #88398a;
                        color: #fff;
                        border-bottom: 0 solid transparent;
                        }
                        
                        .skin-purple .sidebar-menu>li.active>a, .skin-purple .sidebar-menu>li:hover>a {
                        color: #fff;
                        background: #1e282c;
                        border-left-color: #88398a;
                        }
                        
                        
                        "
                         )
                       )
                      )
                    
                    )


# 10. Server --------------------------------------------------------------

server <- function(input, output) {
  
  
} 


# 11. Shiny App -----------------------------------------------------------

shinyApp(ui = ui, server = server)
