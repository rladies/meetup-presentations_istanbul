#######################################################################
################# 5.BÖLÜM  - Shiny Dashboard Layout  ##################
#######################################################################


# 1. Kütüphaneler ---------------------------------------------------------

library(shiny)
library(shinydashboard)
library(tidyverse)




# 2. Header ---------------------------------------------------------------

header <- dashboardHeader(
  title = "R-Ladies İstanbul"
) 



# 3. Sidebar --------------------------------------------------------------

sidebar <- dashboardSidebar( 

  sidebarMenu(
    
    menuItem(tabName = "menu1", text = "Menu 1", icon = icon("r-project"))
  ) 
)


# 4. Body -----------------------------------------------------------------

body <- dashboardBody(


# 5. fluidRow: Satır Oluşturma --------------------------------------------

  fluidRow(


# 6. column: Sütun Oluşturma ----------------------------------------------

    column(
      width = 3,
      tags$img(src="2.png",height = "%50")
    ),
    
    column(
      width = 9,
      
      fluidRow(

# 7. Input ----------------------------------------------------------------

        selectInput(inputId = "variable1", label = "Select X Variable:",
                    choices = c("Sepal.Length", "Sepal.Width",  "Petal.Length", "Petal.Width"),
                    selected = "Sepal.Length"),
        
        selectInput(inputId = "variable2", label = "Select Y Variable:",
                    choices = c("Sepal.Length", "Sepal.Width",  "Petal.Length", "Petal.Width"),
                    selected = "Petal.Length"),
        
        radioButtons(inputId = "category", label = "Select Species:",
                     choices = c("Red" = "red","Green" = "green", "Blue" = "blue"),
                     selected = "green"),
        
        sliderInput(inputId = "size", 
                    label = "Select Size:",
                    min = 1, max = 6, value = 2)
      ),
      
      fluidRow(

# 8. Output ---------------------------------------------------------------

        plotOutput(outputId = "plot")
        
        )
      
      
      )
    
    )

)




# 9. UI -------------------------------------------------------------------

ui <- dashboardPage(header, sidebar, body, 
                    skin = "purple",

# 10. HTML & UI -----------------------------------------------------------

                    tags$head(
                      tags$style(
                        HTML(
                        "
                        .skin-purple .main-header .navbar {
                        background-color: #88398a;}

                        .skin-purple .main-header .logo {
                        background-color: #88398a;
                        color: #fff;
                        border-bottom: 0 solid transparent;
                        }
                        
                        .skin-purple .sidebar-menu>li.active>a, .skin-purple .sidebar-menu>li:hover>a {
                        color: #fff;
                        background: #1e282c;
                        border-left-color: #88398a;
                        }
                        
                        
                        "
                         )
                       )
                      )
                    
                    )


# 11. Server --------------------------------------------------------------


server <- function(input, output) {
  

# 12. Output --------------------------------------------------------------

  output$plot <- renderPlot({
    
    ggplot(iris, aes_string(input$variable1, input$variable2))+
      geom_point(color = input$category, size = input$size)
    
  })
  
} 

# 13. Shiny App -----------------------------------------------------------

shinyApp(ui = ui, server = server)
